package com.coderman.codemaker.dbops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodemakerDbopsApplicationTests {

    @Test
    void contextLoads() {
    }

}
