/*
import com.coderman.codemaker.Main;
import com.coderman.codemaker.config.ProjectTemplateConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

*/
/**
 * description: ProjectTemplateConfigTest <br>
 * date: 2020/7/7 22:34 <br>
 * author: coderman <br>
 * version: 1.0 <br>
 *//*

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Main.class)
public class ProjectTemplateConfigTest {
    @Autowired
    private ProjectTemplateConfig projectTemplateConfig;

    @Test
    public void testGetConfig(){
        System.out.println(projectTemplateConfig.toString());
    }

}
*/
