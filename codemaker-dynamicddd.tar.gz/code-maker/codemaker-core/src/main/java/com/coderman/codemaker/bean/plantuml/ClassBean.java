package com.coderman.codemaker.bean.plantuml;

import com.coderman.codemaker.bean.dddelement.DomainBoElementBean;

import java.util.List;

/**
 * Description:
 * class 类信息
 * date: 2021/6/28
 *
 * @author fanchunshuai
 * @version 1.0.0
 * @since JDK 1.8
 */
public class ClassBean extends AbstractClassBean{

}
