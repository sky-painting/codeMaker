package com.coderman.codemaker.bean.dddelement;

/**
 * Description:
 * 聚合根元素
 * date: 2021/6/28
 *
 * @author fanchunshuai
 * @version 1.0.0
 * @since JDK 1.8
 */
public class AggregateElementBean extends ElementBean {
}
