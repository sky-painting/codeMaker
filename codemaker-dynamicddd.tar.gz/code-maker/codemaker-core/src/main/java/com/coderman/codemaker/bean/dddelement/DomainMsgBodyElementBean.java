package com.coderman.codemaker.bean.dddelement;

/**
 * Description:
 * date: 2021/6/30
 *
 * @author fanchunshuai
 * @version 1.0.0
 * @since JDK 1.8
 */
public class DomainMsgBodyElementBean  extends ElementBean {
}
