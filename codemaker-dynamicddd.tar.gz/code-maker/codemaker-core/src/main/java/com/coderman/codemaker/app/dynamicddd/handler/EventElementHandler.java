package com.coderman.codemaker.app.dynamicddd.handler;

/**
 * Description:
 * date: 2021/6/30
 *
 * @author fanchunshuai
 * @version 1.0.0
 * @since JDK 1.8
 */
public class EventElementHandler {
}
