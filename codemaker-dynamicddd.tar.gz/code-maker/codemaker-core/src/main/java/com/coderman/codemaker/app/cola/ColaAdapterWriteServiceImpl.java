package com.coderman.codemaker.app.cola;

import com.coderman.codemaker.bean.WriteContentBean;
import com.coderman.codemaker.service.IWriteFileService;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Description:
 * date: 2021/7/6
 *
 * @author fanchunshuai
 * @version 1.0.0
 * @since JDK 1.8
 */
@Component(value = "colaAdapterWriteService")
public class ColaAdapterWriteServiceImpl implements IWriteFileService {
    @Override
    public void writeContent(WriteContentBean writeContentBean) {

    }

    @Override
    public void writeAllContent(String humpClassName, Map<String, Object> varMap, String fast) {

    }

    @Override
    public void writeCommonContent(Map<String, Object> varMap, String fast) {

    }
}
