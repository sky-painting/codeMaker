package com.coderman.codemaker.bean.plantuml;

import java.util.List;

/**
 * Description:
 *
 * 领域接口
 * date: 2021/6/28
 *
 * @author fanchunshuai
 * @version 1.0.0
 * @since JDK 1.8
 */
public class InterfaceBean extends AbstractClassBean{

}
