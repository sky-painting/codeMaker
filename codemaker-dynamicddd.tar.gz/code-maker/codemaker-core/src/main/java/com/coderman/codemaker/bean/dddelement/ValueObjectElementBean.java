package com.coderman.codemaker.bean.dddelement;

/**
 * Description:
 *
 * 值对象实体 元素
 * date: 2021/6/28
 *
 * @author fanchunshuai
 * @version 1.0.0
 * @since JDK 1.8
 */
public class ValueObjectElementBean  extends ElementBean {
}
