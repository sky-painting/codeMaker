package com.coderman.codemaker.service.registry;

import com.coderman.codemaker.service.AbstractVarRegistry;

import java.util.Map;

/**
 * description: PomVarRegsitry <br>
 * date: 2020/7/7 10:06 <br>
 * author: coderman <br>
 * version: 1.0 <br>
 */
public class PomVarRegsitry extends AbstractVarRegistry {
    @Override
    public Map<String, Object> getRegistVarMap() {
        return null;
    }
}
