package com.coderman.codemaker.bean.dddelement;

/**
 * Description:
 * 业务模块实体，领域实体元素
 * date: 2021/6/28
 *
 * @author fanchunshuai
 * @version 1.0.0
 * @since JDK 1.8
 */
public class DomainBoElementBean  extends ElementBean {
}
