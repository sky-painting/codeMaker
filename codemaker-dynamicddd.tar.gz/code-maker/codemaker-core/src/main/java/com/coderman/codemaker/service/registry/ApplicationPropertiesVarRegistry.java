package com.coderman.codemaker.service.registry;

import com.coderman.codemaker.service.AbstractVarRegistry;

import java.util.Map;

/**
 * description: ApplicationPropertiesRegistry <br>
 * date: 2020/7/7 10:05 <br>
 * author: coderman <br>
 * version: 1.0 <br>
 */
public class ApplicationPropertiesVarRegistry extends AbstractVarRegistry {
    @Override
    public Map<String, Object> getRegistVarMap() {
        return null;
    }
}
