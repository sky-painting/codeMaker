package com.coderman.codemaker.bean.dddelement;

/**
 * Description:命令实体
 * date: 2021/7/5
 *
 * @author fanchunshuai
 * @version 1.0.0
 * @since JDK 1.8
 */
public class CommandElementBean extends ElementBean {
}
