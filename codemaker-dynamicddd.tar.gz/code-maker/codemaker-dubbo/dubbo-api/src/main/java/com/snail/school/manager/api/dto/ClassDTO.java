package com.snail.school.manager.api.dto;

import java.util.Date;
import java.math.BigDecimal;
import lombok.Data;
import lombok.ToString;
import java.io.Serializable;


/**
* @Description:DTO类
* @Author:fanchunshuai
* @CreateTime:2021-07-06 11:07:37
* @version v1.0
*/
@Data
@ToString
public class ClassDTO  implements Serializable {

	/**  **/
	private Long id;
	/**  **/
	private String manager;
	/**  **/
	private Integer studentCount;
	/** 年级 **/
	private Integer gradeNum;
	/** 班级 **/
	private Integer classNum;

}