package com.snail.school.manager.api.dto;

import java.util.Date;
import java.math.BigDecimal;
import lombok.Data;
import lombok.ToString;
import java.io.Serializable;


/**
* @Description:DTO类
* @Author:fanchunshuai
* @CreateTime:2021-07-06 11:07:37
* @version v1.0
*/
@Data
@ToString
public class StudentDTO  implements Serializable {

	/**  **/
	private Long id;
	/**  **/
	private String studentName;
	/**  **/
	private String studentCode;
	/**  **/
	private String sex;
	/**  **/
	private Integer age;
	/** 班级ID **/
	private Long classId;

}