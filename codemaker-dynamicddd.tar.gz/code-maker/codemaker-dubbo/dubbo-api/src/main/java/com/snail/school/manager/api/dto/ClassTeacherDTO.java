package com.snail.school.manager.api.dto;

import java.util.Date;
import java.math.BigDecimal;
import lombok.Data;
import lombok.ToString;
import java.io.Serializable;


/**
* @Description:DTO类
* @Author:fanchunshuai
* @CreateTime:2021-07-06 11:07:37
* @version v1.0
*/
@Data
@ToString
public class ClassTeacherDTO  implements Serializable {

	/**  **/
	private Long id;
	/**  **/
	private Long classId;
	/**  **/
	private Long teacherId;

}