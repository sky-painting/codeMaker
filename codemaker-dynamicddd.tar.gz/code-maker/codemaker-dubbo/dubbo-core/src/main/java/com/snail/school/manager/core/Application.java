package com.snail.school.manager.core;


import org.apache.dubbo.config.spring.context.annotation.DubboComponentScan;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
* @Description:应用启动入口
* @Author:fanchunshuai
* @CreateTime:2021-07-06 11:07:37
* @version v1.0
*/
@DubboComponentScan(basePackages = "com.snail.school.manager.core")
@EnableDubbo //开启Dubbo的注解支持
@SpringBootApplication(scanBasePackages = {"com.snail.school.manager"})
@MapperScan(basePackages = "com.snail.school.manager.common")
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}
