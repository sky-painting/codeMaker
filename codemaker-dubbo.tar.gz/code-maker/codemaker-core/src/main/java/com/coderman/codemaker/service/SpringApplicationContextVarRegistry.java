package com.coderman.codemaker.service;

import java.util.Map;

/**
 * description: SpringApplicationContextVarRegistry <br>
 * date: 2020/7/7 10:11 <br>
 * author: coderman <br>
 * version: 1.0 <br>
 */
public class SpringApplicationContextVarRegistry extends AbstractVarRegistry {
    @Override
    public Map<String, Object> getRegistVarMap() {
        return null;
    }
}
