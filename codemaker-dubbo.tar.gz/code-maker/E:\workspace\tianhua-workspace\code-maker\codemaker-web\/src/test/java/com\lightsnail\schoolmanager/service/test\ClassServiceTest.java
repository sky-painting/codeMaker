package com.lightsnail.schoolmanager.service.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lightsnail.schoolmanager.service.ClassService;
import com.lightsnail.schoolmanager.vo.ClassVO;
import com.lightsnail.schoolmanager.Application;

import com.coderman.utils.response.ResultDataDto;
import com.coderman.utils.response.ResultDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.alibaba.fastjson.JSON;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.junit4.SpringRunner;

/**
* @Description:单元测试
* @Author:fanchunshuai
* @CreateTime:2021-06-25 14:48:30
* @version v1.0
*/
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment= SpringBootTest.WebEnvironment.RANDOM_PORT,classes = {Application.class})
public class ClassServiceTest{
	
	protected Logger logger = LoggerFactory.getLogger(ClassServiceTest.class);

	@Autowired
	private ClassService classService;
    @Autowired
    private TestRestTemplate restTemplate;

	/**
     * @Description:测试新增 接口
     */
    @Test
    public void testAdd(){
        //todo test code
		ClassVO vo = new ClassVO();

		ResultDto resultDto = restTemplate.postForEntity("/class/add",vo, ResultDto.class).getBody();
		System.out.println(JSON.toJSONString(resultDto));
    }

	/**
	 * @Description:测试修改
	 */
	@Test
	public void testUpdate(){
		//todo test code
		ClassVO vo = new ClassVO();
		ResultDto resultDto = restTemplate.postForEntity("/class/update",vo, ResultDto.class).getBody();
		System.out.println(JSON.toJSONString(resultDto));
	}

	/**
	 * @Description:测试删除根据id删除
	 */
    @Test
	public void testDelete(){
		//todo test code
		long id = 1L;
		ResultDto resultDto = restTemplate.postForEntity("/class/delete",id, ResultDto.class).getBody();
		System.out.println(JSON.toJSONString(resultDto));
	}

	/**
	 * @Description:但是根据ID获取单条记录
	 */
	@Test
	public void testGetById(){
		//todo test code
		ResultDataDto resultDataDto = restTemplate.getForEntity("/class/get?id=1",ResultDataDto.class).getBody();
		System.out.println(JSON.toJSONString(resultDataDto));
	}

	/**
	 * @Description:测试分页获取记录
	 */
	@Test
	public void getPage(){
		//todo test code
	}

	/**
	 * @Description:测试禁用状态
	 */
	@Test
	public void testDisable(){
		//todo test code
	}
	/**
	 * @Description:测试启用状态
	 */
	@Test
	public void testEnable(){
		//todo test code
	}
}
